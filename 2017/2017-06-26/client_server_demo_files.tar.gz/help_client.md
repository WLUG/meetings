## client_1 through client_5 

### A client application with D-Bus communicatons to the server application

If launched when the server is running then it will subscribe and receive the
data that the server publishes. It also allow the client to make method calls
to the server.

The client and server use the default D-Bus name of 
**org.example.project_1.server_1**

If the server has been started with a different D-Bus name then this can be
entered into the command line on launching the client. Command line arguments
are:

-p= --project=  Project folder name. E.g. *bike*

-s= --server=   Server folder name. E.g. *speedo*

-a= --app=      Server Application filename. E.g. *wheel* 

For example:

`$ python3 client_5 --project=bike --server=speedo --app=wheel`

The client also has the following command line flags:

-h --help       Provide this help file.

