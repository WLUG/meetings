## server_generator 

### A program to generate a server application with system D-Bus communicatons

The server_generator defaults to creating a server template file with a D-Bus 
to name of **org.example.project_1.server_1**

The server_generator may be launched so it provides a different D-Bus name. 
This can be entered into the command line on launching the server_generator. 
The server template application that is generated, *app_1*, will inherit this 
D-Bus name.

Command line arguments are:

-p= --project=  Project folder name. E.g. *bike*

-s= --server=   Server folder name. E.g. *speedo*

-a= --app=      Server Application filename. E.g. *wheel* 

For example:

`$ python3 server_generator --project=bike --server=speedo --app=wheel`

The server_generator also has the following command line flags:

-c --create     Create the template server. This is the default. 

-r --remove     Remove the template server.

-d --dot        Prefix the project folder with a dot. i.e. A hidden folder.

-h --help       Provide this help file.


The template server file that is created does not contain any help information.
Print() functions in the template server code will be written to the journalctl 
file. Also any template server program error information is written to the
journalctl file.

Use $ journalctl to examing this file for messages from the template server.



