Help Client Full - --help Not implemented.
Please use -h instead.

TODO: Write a full User Manual style of help
