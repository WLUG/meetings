help_full_server_generator.md

--help file - Not yet implemented

Please use -h
